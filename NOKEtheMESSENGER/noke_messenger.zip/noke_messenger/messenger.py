import os
from twilio.rest import Client
from dotenv import load_dotenv

load_dotenv()

TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER")
SENDGRID_API_KEY = os.getenv("SENDGRID_API_KEY")
FROM_EMAIL = os.getenv("FROM_EMAIL", "noreply@yourdomain.com")
COMPANY_NAME = os.getenv("COMPANY_NAME", "NOKE Smart Entry")

# Opt-out footer required by TCPA
SMS_FOOTER = "\n\nReply STOP to unsubscribe."


def send_sms(to_phone, message, contact_name=""):
    """Send an SMS via Twilio."""
    try:
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        full_message = message + SMS_FOOTER

        msg = client.messages.create(
            body=full_message,
            from_=TWILIO_PHONE_NUMBER,
            to=to_phone
        )

        return {
            "success": True,
            "contact": contact_name,
            "phone": to_phone,
            "sid": msg.sid
        }

    except Exception as e:
        return {
            "success": False,
            "contact": contact_name,
            "phone": to_phone,
            "error": str(e)
        }


def send_email(to_email, message, contact_name=""):
    """Send an email via SendGrid."""
    try:
        import sendgrid
        from sendgrid.helpers.mail import Mail

        sg = sendgrid.SendGridAPIClient(api_key=SENDGRID_API_KEY)

        email = Mail(
            from_email=FROM_EMAIL,
            to_emails=to_email,
            subject=f"Message from {COMPANY_NAME}",
            plain_text_content=message + f"\n\n---\nSent by {COMPANY_NAME}\nTo unsubscribe, reply STOP."
        )

        response = sg.send(email)

        return {
            "success": response.status_code in [200, 201, 202],
            "contact": contact_name,
            "email": to_email,
            "status_code": response.status_code
        }

    except Exception as e:
        return {
            "success": False,
            "contact": contact_name,
            "email": to_email,
            "error": str(e)
        }
